
$(document).ready(() =>
{
    $('#debug_result').html("jQuery loaded<br>Script loaded");
});